  /**
  ****************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32WLxx devices support on MDK-ARM.
  ****************************************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                      www.st.com/SLA0044
  *
  *****************************************************************************************************/
  These packages contains the needed files to be installed in order to support STM32WLxx 
  devices by MDK-ARM v5.25 and laters.
  
 Running the "Keil.STM32WLxx_DFP.1.1.1.pack" adds the following:
 ==============================================================
  
 1. Part numbers for  :
  - Dual Core (CM4 & CM0+) Lora lines: STM32WL55xx
  - Dual Core (CM4 & CM0+) non Lora lines: STM32WL54xx
  - Dual Core (CM4 & CM0+) : STM32WL5Mxx
  - Single Core (CM4) Lora lines: STM32WLE5xx
  - Single Core (CM4) non Lora lines: STM32WLE4xx

 2. Automatic STM32WLxx flash algorithm selection

 3. Automatic SVD file selection

 How to use:
 ==========
 * Before installing the files mentioned above, you need to have MDK-ARM v5.25 or later installed. 
  You can download pack from keil web site @ www.keil.com
  
 * Double Clic on  "Keil.STM32WLxx_DFP.1.1.1.pack" in order to install this pack in the Keil install 
 directory.

******************* (C) COPYRIGHT 2021 STMicroelectronics *****END OF FILE*****************************





	



